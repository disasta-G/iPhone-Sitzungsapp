# GGT Sitzungsnotizen

Sprachgesteuerte Sitzungsnotizen-App mit automatischer Transkription (Schweizerdeutsch + Sprechererkennung), KI-Auswertung und direkter Obsidian-Integration.

## Architektur

```
iPhone (PWA)  ←→  VPS Backend  ←→  GitHub (Obsidian Vault)
                        ↓
                  Replicate (Whisper)
                  Anthropic (Claude)
```

Das Frontend spricht nur mit dem Backend — keine API-Keys im Browser. Das Backend synchronisiert den Obsidian Vault über Git mit einem privaten GitHub-Repository.

---

## Was du brauchst

**Accounts und API-Keys:**
- Hostinger VPS (hast du)
- GitHub-Account (kostenlos) für privates Vault-Repo
- Replicate API-Token — für Whisper + Diarization — replicate.com
- Anthropic API-Key (hast du)

**Kosten pro Monat** (20 Sitzungen à 30 Min):
- Replicate (Whisper+Diarization): ~3 CHF
- Anthropic Claude: ~3 CHF
- Hostinger VPS + GitHub: hast du bzw. kostenlos
- **Total: ~6 CHF/Monat**

---

## Setup Schritt für Schritt

### 1. Obsidian Vault als Git-Repository

Auf dem Mac/PC im Vault-Ordner:
```bash
cd ~/Obsidian\ GGT
git init
git remote add origin git@github.com:dein-user/obsidian-ggt.git
git add -A && git commit -m "initial"
git push -u origin main
```

Auf dem iPhone: **Obsidian Git Plugin** installieren (Community Plugins) und mit GitHub verknüpfen. Automatisches Pull beim Öffnen, Push nach Änderungen.

### 2. VPS vorbereiten

Via SSH auf dem Hostinger-VPS:
```bash
# Node.js 20 installieren
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs git nginx certbot python3-certbot-nginx

# App-Verzeichnis
mkdir -p ~/ggt-app/public
cd ~/ggt-app

# Vault via Git klonen (mit SSH-Key für GitHub)
ssh-keygen -t ed25519
cat ~/.ssh/id_ed25519.pub  # Diesen Key auf GitHub als Deploy Key hinzufügen
git clone git@github.com:dein-user/obsidian-ggt.git vault

# Backend-Dateien hochladen (via SFTP)
# server.js → ~/ggt-app/server.js
# index.html → ~/ggt-app/public/index.html

# Dependencies
npm init -y
npm install express cors multer
```

### 3. Umgebungsvariablen setzen

`~/ggt-app/.env` erstellen:
```bash
VAULT_PATH=/home/user/ggt-app/vault
API_SECRET=wähle-ein-starkes-passwort-min-20-zeichen
REPLICATE_TOKEN=r8_deinToken
ANTHROPIC_KEY=sk-ant-deinKey
PORT=3000
```

### 4. Backend als Dienst starten

```bash
npm install -g pm2

pm2 start server.js --name ggt --env production \
  --node-args="-r dotenv/config"
pm2 save
pm2 startup
```

### 5. Nginx + HTTPS

```bash
sudo nano /etc/nginx/sites-available/ggt
```

Inhalt:
```nginx
server {
    server_name ggt.deine-domain.ch;
    client_max_body_size 100M;

    location /api/ {
        proxy_pass http://localhost:3000/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_read_timeout 300s;
    }

    location / {
        root /home/user/ggt-app/public;
        try_files $uri /index.html;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/ggt /etc/nginx/sites-enabled/
sudo certbot --nginx -d ggt.deine-domain.ch
```

### 6. DNS

Bei deinem Domain-Provider einen A-Record setzen:
`ggt.deine-domain.ch → VPS-IP`

### 7. iPhone

Safari → `https://ggt.deine-domain.ch` → Teilen → **"Zum Home-Bildschirm"**

Beim ersten Start:
- Backend URL: `https://ggt.deine-domain.ch/api`
- API-Passwort: das was du in `.env` gesetzt hast

Keys werden lokal gespeichert — nur einmal eingeben.

---

## API-Keys besorgen

### Replicate
1. replicate.com → Sign up (mit GitHub)
2. Account → API Tokens → Create
3. ~0.01 USD pro Minute Audio

### Anthropic
Hast du.

---

## Vault-Struktur (automatisch)

```
Obsidian GGT/
└── 01-Projekte/
    └── Müller-Chur/
        └── Sitzungen/
            ├── 2026-04-17-Sitzung.md
            └── 2026-05-03-Sitzung.md
```

Jede Notiz enthält:
- YAML-Frontmatter (datum, projekt, anwesende, tags)
- Strukturierter Bericht mit Kategorien
- Offene Pendenzen als `- [ ]`

Erledigte Pendenzen werden in allen Notizen automatisch auf `- [x]` aktualisiert.

---

## Troubleshooting

**"Mikrofon-Fehler"** → HTTPS zwingend erforderlich (Schritt 5)

**"Verbindung fehlgeschlagen"** → Firewall/Nginx prüfen, `pm2 logs ggt`

**Transkription dauert lange** → Normal, 60 Min Audio ≈ 30-60 Sek Verarbeitung

**Sprecher werden falsch zugeordnet** → Reihenfolge der Anwesenden-Namen entscheidet. Der erste Name geht an den ersten erkannten Sprecher.

**Git-Konflikte** → Bei parallelen Änderungen: `cd vault && git pull --rebase` manuell
