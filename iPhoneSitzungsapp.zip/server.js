// GGT Sitzungsnotizen Backend v2
// Verbesserungen:
// - Obsidian-Struktur nach Vorlage (YAML, Sections mit Emojis, Horizontal Rules)
// - Filename: [Datum]-[Projekt]-Sitzung.md
// - emailHtml + emailMd getrennt (Outlook-kompatible HTML-Tags statt **Markdown**)
// - Neue Kategorie "Traktanden / Themen"
// - zeit-Feld im Frontmatter
// - Anwesende aus ergänzter Liste (vom Frontend in /themen und /bericht)

require('dotenv').config();
const express = require('express');
const multer = require('multer');
const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const Anthropic = require('@anthropic-ai/sdk');
const Replicate = require('replicate');

const app = express();
const PORT = process.env.PORT || 3001;
const VAULT = process.env.VAULT_PATH;
const API_SECRET = process.env.API_SECRET;
const REPLICATE_TOKEN = process.env.REPLICATE_TOKEN;
const ANTHROPIC_KEY = process.env.ANTHROPIC_KEY;

if (!VAULT || !API_SECRET || !REPLICATE_TOKEN || !ANTHROPIC_KEY) {
  console.error('FEHLER: VAULT_PATH, API_SECRET, REPLICATE_TOKEN, ANTHROPIC_KEY müssen gesetzt sein');
  process.exit(1);
}

const anthropic = new Anthropic({ apiKey: ANTHROPIC_KEY });
const replicate = new Replicate({ auth: REPLICATE_TOKEN });

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fsSync.existsSync(UPLOAD_DIR)) fsSync.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const sitzungsDir = path.join(UPLOAD_DIR, req.sitzungsId || 'temp');
    fsSync.mkdirSync(sitzungsDir, { recursive: true });
    cb(null, sitzungsDir);
  },
  filename: (req, file, cb) => cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } });

const sessions = {};

app.use(express.json({ limit: '10mb' }));
app.use((req, res, next) => {
  const secret = req.headers['x-api-secret'];
  if (secret !== API_SECRET) return res.status(401).json({ error: 'Unauthorized' });
  next();
});

// ======== Helpers ========
function gitPull() {
  try { execSync('git pull --rebase --autostash', { cwd: VAULT, stdio: 'pipe' }); } catch (e) { console.warn('Git pull:', e.message); }
}

function gitCommitPush(msg) {
  try {
    execSync('git add -A', { cwd: VAULT });
    execSync(`git commit -m "${msg}" || true`, { cwd: VAULT, shell: '/bin/bash' });
    execSync('git push', { cwd: VAULT });
  } catch (e) { console.warn('Git commit/push:', e.message); }
}

function listProjekte() {
  const projekteDir = path.join(VAULT, '01-Projekte');
  if (!fsSync.existsSync(projekteDir)) return [];
  return fsSync.readdirSync(projekteDir, { withFileTypes: true })
    .filter(d => d.isDirectory() && !d.name.startsWith('.') && !d.name.startsWith('_'))
    .map(d => d.name).sort();
}

async function findOpenPendenzen(projektName) {
  const projektDir = path.join(VAULT, '01-Projekte', projektName);
  if (!fsSync.existsSync(projektDir)) return [];
  const pendenzen = [];
  
  // Rekursiv alle .md Dateien im Projektordner finden
  function walkDir(dir, relativeBase = '') {
    const entries = fsSync.readdirSync(dir, { withFileTypes: true });
    const files = [];
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const relPath = relativeBase ? path.join(relativeBase, entry.name) : entry.name;
      if (entry.isDirectory() && !entry.name.startsWith('.') && entry.name !== 'Assets') {
        files.push(...walkDir(fullPath, relPath));
      } else if (entry.isFile() && entry.name.endsWith('.md')) {
        files.push({ fullPath, relPath, name: entry.name });
      }
    }
    return files;
  }
  
  const allFiles = walkDir(projektDir);
  // Sortieren: neueste zuerst (nach Datumsprefix falls vorhanden)
  allFiles.sort((a, b) => b.name.localeCompare(a.name));
  
  for (const fileInfo of allFiles) {
    const content = await fs.readFile(fileInfo.fullPath, 'utf8');
    const lines = content.split('\n');
    // Datum aus Dateinamen extrahieren oder Fallback
    const datumMatch = fileInfo.name.match(/^(\d{4}-\d{2}-\d{2})/);
    let datum = datumMatch ? datumMatch[1] : '';
    // Falls kein Datum im Namen, aus YAML-Frontmatter holen
    if (!datum) {
      const yamlMatch = content.match(/^---\s*\n([\s\S]*?)\n---/);
      if (yamlMatch) {
        const dm = yamlMatch[1].match(/datum:\s*(\d{4}-\d{2}-\d{2})/);
        if (dm) datum = dm[1];
      }
    }
    lines.forEach((line, idx) => {
      // Match offene Checkboxen: "- [ ] Text" oder "* [ ] Text"
      const m = line.match(/^\s*[-*]\s*\[\s\]\s*(.+)$/);
      if (m) {
        let text = m[1].trim();
        // Entferne Reminder-Plugin-Syntax wie (@2026-04-20)
        text = text.replace(/\s*\(@[^)]+\)\s*/g, '').trim();
        // Entferne Tasks-Plugin Emojis wie 📅 2026-04-20, ⏫, 🔼 etc.
        text = text.replace(/[📅⏫🔼🔽🔺⏬⏳🛫✅❌🏁]\s*\d{4}-\d{2}-\d{2}/g, '').trim();
        text = text.replace(/[⏫🔼🔽🔺⏬]/g, '').trim();
        if (text && text.length > 2 && !pendenzen.find(p => p.text.toLowerCase() === text.toLowerCase())) {
          pendenzen.push({
            id: `${fileInfo.relPath}:${idx}`,
            text,
            datum,
            file: fileInfo.relPath
          });
        }
      }
    });
  }
  return pendenzen;
}

// ======== Endpunkte ========
app.get('/projekte', (req, res) => { res.json({ projekte: listProjekte() }); });

app.get('/pendenzen', async (req, res) => {
  try {
    gitPull();
    const projekt = req.query.projekt;
    if (!projekt) return res.status(400).json({ error: 'projekt fehlt' });
    const pendenzen = await findOpenPendenzen(projekt);
    res.json({ pendenzen });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/sitzung', (req, res, next) => {
  req.sitzungsId = 'sit-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  upload.fields([{ name: 'audio', maxCount: 1 }, { name: 'fotos', maxCount: 20 }])(req, res, next);
}, (req, res) => {
  try {
    const sitzungsId = req.sitzungsId;
    const audio = req.files.audio?.[0];
    const fotos = req.files.fotos || [];
    if (!audio) return res.status(400).json({ error: 'audio fehlt' });
    const fotoZeiten = [].concat(req.body.foto_zeiten || []).map(z => parseInt(z) || 0);
    sessions[sitzungsId] = {
      id: sitzungsId,
      audioPath: audio.path,
      fotos: fotos.map((f, i) => ({ path: f.path, timestamp: fotoZeiten[i] || 0, name: f.filename })),
      projekt: req.body.projekt,
      anwesende: req.body.anwesende,
      transkript: null,
      fotoAnalysen: [],
      topics: [],
      createdAt: Date.now()
    };
    res.json({ sitzungsId });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/transkribieren', async (req, res) => {
  try {
    const id = req.query.id;
    const s = sessions[id];
    if (!s) return res.status(404).json({ error: 'Sitzung nicht gefunden' });
    const audioBuffer = await fs.readFile(s.audioPath);
    const audioBase64 = 'data:audio/webm;base64,' + audioBuffer.toString('base64');
    const output = await replicate.run(
      'thomasmol/whisper-diarization:1495a9cddc83b2203b0d8d3516e38b80fd1572ebc4bc5700ac1da56a9b3ed886',
      { input: { file_string: audioBase64, language: 'de', prompt: 'Schweizerdeutsch, Hochdeutsch, Baustelle, Heizung, Sanitär, Lüftung, Giovanoli.' } }
    );
    s.transkript = output;
    res.json({ ok: true, segments: output.segments?.length || 0 });
  } catch (e) { console.error('transkribieren:', e); res.status(500).json({ error: e.message }); }
});

app.post('/fotos-analyse', async (req, res) => {
  try {
    const id = req.query.id;
    const s = sessions[id];
    if (!s) return res.status(404).json({ error: 'Sitzung nicht gefunden' });
    s.fotoAnalysen = [];
    for (const foto of s.fotos) {
      const imgBuffer = await fs.readFile(foto.path);
      const imgBase64 = imgBuffer.toString('base64');
      const ext = path.extname(foto.path).slice(1).toLowerCase();
      const mediaType = ext === 'jpg' ? 'image/jpeg' : `image/${ext}`;
      const resp = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514', max_tokens: 300,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: mediaType, data: imgBase64 } },
          { type: 'text', text: 'Kurze Beschreibung (1-2 Sätze) was auf diesem Baustellen-Foto zu sehen ist. Technisch und präzise.' }
        ]}]
      });
      s.fotoAnalysen.push({ timestamp: foto.timestamp, beschreibung: resp.content[0].text });
    }
    res.json({ ok: true, anzahl: s.fotoAnalysen.length });
  } catch (e) { console.error('fotos-analyse:', e); res.status(500).json({ error: e.message }); }
});

app.post('/themen', async (req, res) => {
  try {
    const id = req.query.id;
    const s = sessions[id];
    if (!s) return res.status(404).json({ error: 'Sitzung nicht gefunden' });
    const { erledigte = [], anwesende = '' } = req.body;
    if (anwesende) s.anwesende = anwesende;

    const segments = s.transkript?.segments || [];
    const transkriptText = segments.map(seg => {
      const speaker = seg.speaker || 'SPEAKER';
      return `[${speaker}] ${seg.text}`;
    }).join('\n');

    const fotoKontext = s.fotoAnalysen.map(f => `[Foto bei ${Math.floor(f.timestamp/60)}:${String(f.timestamp%60).padStart(2,'0')}] ${f.beschreibung}`).join('\n');

    const prompt = `Du bist ein Assistent für Protokollierung von Baustellen-Sitzungen bei Giovanoli Gebäudetechnik GmbH. Analysiere das folgende Transkript einer Sitzung und extrahiere alle relevanten Themen.

ANWESENDE: ${s.anwesende}

TRANSKRIPT:
${transkriptText}

${fotoKontext ? '\nFOTO-KONTEXT:\n' + fotoKontext : ''}

${erledigte.length ? '\nFOLGENDE PENDENZEN WURDEN IN DIESER SITZUNG ALS ERLEDIGT MARKIERT:\n' + erledigte.map(t=>`- ${t}`).join('\n') : ''}

Extrahiere daraus strukturiert alle Themen und gib sie als JSON-Array zurück. Jedes Thema hat folgende Felder:
- text: Klare, präzise Formulierung (1-2 Sätze)
- kategorie: EINE von ["Traktanden / Themen", "Mängel & Pendenzen", "Ausgeführte Arbeiten", "Nächste Schritte", "Beschlüsse", "Bemerkungen"]
- verantwortlich: Name der Person (falls erkennbar) oder ""
- termin: Datum/Frist (falls erwähnt) oder ""
- prio: "hoch" / "mittel" / "niedrig"

Sei präzise, erfinde nichts. Wenn das Transkript unklar ist, formuliere konservativ. Schreibe in Hochdeutsch, auch wenn Schweizerdeutsch gesprochen wurde.

Antworte NUR mit einem gültigen JSON-Array, ohne Markdown-Code-Blöcke, ohne Erklärung.`;

    const resp = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514', max_tokens: 4000,
      messages: [{ role: 'user', content: prompt }]
    });

    let text = resp.content[0].text.trim();
    text = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '').trim();
    let topics = [];
    try { topics = JSON.parse(text); } catch (e) {
      const m = text.match(/\[[\s\S]*\]/);
      if (m) topics = JSON.parse(m[0]);
    }
    s.topics = topics;
    res.json({ topics });
  } catch (e) { console.error('themen:', e); res.status(500).json({ error: e.message }); }
});

app.post('/bericht', async (req, res) => {
  try {
    const id = req.query.id;
    const s = sessions[id];
    if (!s) return res.status(404).json({ error: 'Sitzung nicht gefunden' });
    const { selectedIdx = [], erledigte = [], datum, datumFile, zeit, anwesende } = req.body;
    if (anwesende) s.anwesende = anwesende;

    const selected = selectedIdx.map(i => s.topics[i]).filter(Boolean);

    // Erledigte Pendenzen ermitteln
    const erledigteTexte = [];
    for (const pendId of erledigte) {
      const pendenzen = await findOpenPendenzen(s.projekt);
      const p = pendenzen.find(x => x.id === pendId);
      if (p) erledigteTexte.push(p.text);
    }

    // Gruppieren nach Kategorie
    const byKat = {};
    selected.forEach(t => {
      if (!byKat[t.kategorie]) byKat[t.kategorie] = [];
      byKat[t.kategorie].push(t);
    });

    // ===== Obsidian-Markdown nach Vorlage =====
    let md = `---\n`;
    md += `typ: besprechung\n`;
    md += `datum: ${datumFile}\n`;
    md += `projekt: ${s.projekt}\n`;
    md += `ort: Baustelle\n`;
    md += `tags: [besprechung, baustelle]\n`;
    md += `---\n\n`;

    md += `# Besprechung – ${s.projekt}\n`;
    md += `**Datum:** ${datum} um ${zeit} Uhr  \n`;
    md += `**Ort:** Baustelle  \n`;
    md += `**Teilnehmer:** ${s.anwesende}\n\n`;
    md += `---\n\n`;

    // Traktanden / Themen
    md += `## 📋 Traktanden / Themen\n\n`;
    const traktanden = byKat['Traktanden / Themen'] || [];
    if (traktanden.length) {
      traktanden.forEach(t => md += `- ${t.text}\n`);
    } else {
      // Alle anderen Themen als Traktanden-Übersicht auflisten
      const andereThemen = selected.filter(t => t.kategorie !== 'Traktanden / Themen' && t.kategorie !== 'Bemerkungen');
      if (andereThemen.length) {
        andereThemen.slice(0, 5).forEach(t => md += `- ${t.text.split('.')[0].substring(0, 80)}\n`);
      } else {
        md += `- \n`;
      }
    }
    md += `\n---\n\n`;

    // Besprochenes & Entscheide
    md += `## 🔨 Besprochenes & Entscheide\n\n`;
    const besprochenes = [...(byKat['Ausgeführte Arbeiten']||[]), ...(byKat['Beschlüsse']||[])];
    if (besprochenes.length) {
      besprochenes.forEach(t => {
        const meta = [t.verantwortlich, t.termin].filter(Boolean).join(', ');
        md += `- ${t.text}${meta ? ` *(${meta})*` : ''}\n`;
      });
    } else {
      md += `- \n`;
    }
    md += `\n---\n\n`;

    // Aufgaben / Pendenzen
    md += `## ✅ Aufgaben / Pendenzen\n\n`;
    // Erst erledigte aus vorherigen Sitzungen
    if (erledigteTexte.length) {
      erledigteTexte.forEach(t => md += `- [x] ${t} ✅\n`);
    }
    // Dann neue offene
    const neuePendenzen = [...(byKat['Mängel & Pendenzen']||[]), ...(byKat['Nächste Schritte']||[])];
    if (neuePendenzen.length) {
      neuePendenzen.forEach(t => {
        const meta = [t.verantwortlich, t.termin].filter(Boolean).join(', ');
        md += `- [ ] ${t.text}${meta ? ` *(${meta})*` : ''}\n`;
      });
    } else if (!erledigteTexte.length) {
      md += `- [ ] \n`;
    }
    md += `\n---\n\n`;

    // Fotos / Anhänge
    md += `## 📸 Fotos / Anhänge\n\n`;
    if (s.fotoAnalysen.length) {
      s.fotoAnalysen.forEach((f, i) => {
        const zeit = `${Math.floor(f.timestamp/60)}:${String(f.timestamp%60).padStart(2,'0')}`;
        md += `- Foto ${i+1} (${zeit}): ${f.beschreibung}\n`;
      });
    } else {
      md += `- \n`;
    }
    md += `\n---\n\n`;

    // Sonstiges / Bemerkungen
    md += `## 📝 Sonstiges / Bemerkungen\n\n`;
    const bemerkungen = byKat['Bemerkungen'] || [];
    if (bemerkungen.length) {
      bemerkungen.forEach(t => md += `- ${t.text}\n`);
    } else {
      md += `- \n`;
    }
    md += `\n---\n\n`;

    md += `*Erstellt: ${datum} um ${zeit} Uhr*\n`;

    // ===== Datei speichern =====
    const sitzungenDir = path.join(VAULT, '01-Projekte', s.projekt, 'Sitzungen');
    fsSync.mkdirSync(sitzungenDir, { recursive: true });
    const mdFile = path.join(sitzungenDir, `${datumFile}-${s.projekt}-Sitzung.md`);
    await fs.writeFile(mdFile, md, 'utf8');

    // Fotos kopieren
    const assetsDir = path.join(VAULT, '01-Projekte', s.projekt, 'Assets');
    if (s.fotoAnalysen.length) {
      fsSync.mkdirSync(assetsDir, { recursive: true });
      for (let i = 0; i < s.fotos.length; i++) {
        const src = s.fotos[i].path;
        const dst = path.join(assetsDir, `${datumFile}-foto-${i+1}${path.extname(src)}`);
        await fs.copyFile(src, dst);
      }
    }

    // Erledigte Pendenzen in Quelldateien markieren
    for (const pendId of erledigte) {
      // pendId = "relativer/pfad/file.md:lineIdx"
      const lastColon = pendId.lastIndexOf(':');
      const relFile = pendId.substring(0, lastColon);
      const idxStr = pendId.substring(lastColon + 1);
      const filePath = path.join(VAULT, '01-Projekte', s.projekt, relFile);
      if (fsSync.existsSync(filePath)) {
        const content = await fs.readFile(filePath, 'utf8');
        const lines = content.split('\n');
        const lineIdx = parseInt(idxStr);
        if (lines[lineIdx] && lines[lineIdx].match(/^\s*[-*]\s*\[\s\]/)) {
          lines[lineIdx] = lines[lineIdx].replace(/^(\s*[-*]\s*)\[\s\]/, '$1[x]') + ' ✅ ' + datumFile;
          await fs.writeFile(filePath, lines.join('\n'), 'utf8');
        }
      }
    }

    gitCommitPush(`Sitzung ${datumFile}: ${s.projekt}`);

    // ===== E-Mail: HTML (Outlook-kompatibel) + Markdown =====
    const { emailHtml, emailMd } = buildEmail(s, selected, erledigteTexte, datum, zeit);

    res.json({ ok: true, markdown: md, emailHtml, emailMd, dateiname: `${datumFile}-${s.projekt}-Sitzung.md` });
  } catch (e) {
    console.error('bericht:', e);
    res.status(500).json({ error: e.message });
  }
});

function escapeHtml(s){
  if(!s) return '';
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function buildEmail(s, selected, erledigteTexte, datum, zeit) {
  // Gruppieren
  const byKat = {};
  selected.forEach(t => {
    if (!byKat[t.kategorie]) byKat[t.kategorie] = [];
    byKat[t.kategorie].push(t);
  });

  // ===== HTML-Version (für Outlook) =====
  let html = '';
  html += `<p>Guten Tag,</p>`;
  html += `<p>anbei die Zusammenfassung der Besprechung vom <strong>${escapeHtml(datum)}</strong> (${escapeHtml(zeit)}) zum Projekt <strong>${escapeHtml(s.projekt)}</strong>.</p>`;
  html += `<p><strong>Teilnehmer:</strong> ${escapeHtml(s.anwesende)}</p>`;

  const traktanden = byKat['Traktanden / Themen'] || [];
  if (traktanden.length) {
    html += `<h3 style="margin-top:16px;margin-bottom:6px">Traktanden / Themen</h3><ul style="margin-top:0">`;
    traktanden.forEach(t => html += `<li>${escapeHtml(t.text)}</li>`);
    html += `</ul>`;
  }

  const besprochenes = [...(byKat['Ausgeführte Arbeiten']||[]), ...(byKat['Beschlüsse']||[])];
  if (besprochenes.length) {
    html += `<h3 style="margin-top:16px;margin-bottom:6px">Besprochenes &amp; Entscheide</h3><ul style="margin-top:0">`;
    besprochenes.forEach(t => {
      const meta = [t.verantwortlich, t.termin].filter(Boolean).join(', ');
      html += `<li>${escapeHtml(t.text)}${meta ? ` <em style="color:#666">(${escapeHtml(meta)})</em>` : ''}</li>`;
    });
    html += `</ul>`;
  }

  const neuePendenzen = [...(byKat['Mängel & Pendenzen']||[]), ...(byKat['Nächste Schritte']||[])];
  if (neuePendenzen.length || erledigteTexte.length) {
    html += `<h3 style="margin-top:16px;margin-bottom:6px">Aufgaben / Pendenzen</h3><ul style="margin-top:0">`;
    erledigteTexte.forEach(t => html += `<li style="color:#888"><s>${escapeHtml(t)}</s> ✅ erledigt</li>`);
    neuePendenzen.forEach(t => {
      const verant = t.verantwortlich ? ` <strong>${escapeHtml(t.verantwortlich)}</strong>` : '';
      const termin = t.termin ? ` <em>bis ${escapeHtml(t.termin)}</em>` : '';
      html += `<li>${escapeHtml(t.text)}${verant}${termin}</li>`;
    });
    html += `</ul>`;
  }

  const bemerkungen = byKat['Bemerkungen'] || [];
  if (bemerkungen.length) {
    html += `<h3 style="margin-top:16px;margin-bottom:6px">Bemerkungen</h3><ul style="margin-top:0">`;
    bemerkungen.forEach(t => html += `<li>${escapeHtml(t.text)}</li>`);
    html += `</ul>`;
  }

  html += `<p style="margin-top:20px">Bei Fragen oder Ergänzungen gerne zurückmelden.</p>`;
  html += `<p>Freundliche Grüsse<br>Giovanoli Gebäudetechnik GmbH</p>`;

  // ===== Plain-Text/Markdown Fallback =====
  let md = `Guten Tag\n\nanbei die Zusammenfassung der Besprechung vom ${datum} (${zeit}) zum Projekt ${s.projekt}.\n\n`;
  md += `Teilnehmer: ${s.anwesende}\n\n`;
  if (traktanden.length) { md += `TRAKTANDEN / THEMEN\n`; traktanden.forEach(t => md += `• ${t.text}\n`); md += `\n`; }
  if (besprochenes.length) {
    md += `BESPROCHENES & ENTSCHEIDE\n`;
    besprochenes.forEach(t => { const meta=[t.verantwortlich,t.termin].filter(Boolean).join(', '); md += `• ${t.text}${meta?` (${meta})`:''}\n`; });
    md += `\n`;
  }
  if (neuePendenzen.length || erledigteTexte.length) {
    md += `AUFGABEN / PENDENZEN\n`;
    erledigteTexte.forEach(t => md += `• [erledigt] ${t}\n`);
    neuePendenzen.forEach(t => { const meta=[t.verantwortlich,t.termin].filter(Boolean).join(', '); md += `• ${t.text}${meta?` (${meta})`:''}\n`; });
    md += `\n`;
  }
  if (bemerkungen.length) { md += `BEMERKUNGEN\n`; bemerkungen.forEach(t => md += `• ${t.text}\n`); md += `\n`; }
  md += `Bei Fragen oder Ergänzungen gerne zurückmelden.\n\nFreundliche Grüsse\nGiovanoli Gebäudetechnik GmbH`;

  return { emailHtml: html, emailMd: md };
}

// Cleanup alter Sessions
setInterval(() => {
  const now = Date.now();
  for (const id in sessions) {
    if (now - sessions[id].createdAt > 2 * 60 * 60 * 1000) delete sessions[id];
  }
}, 30 * 60 * 1000);

app.listen(PORT, () => {
  console.log(`GGT Backend v2 läuft auf Port ${PORT}`);
  console.log(`Vault: ${VAULT}`);
});
